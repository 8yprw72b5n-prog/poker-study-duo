Poker Duo V14.2 - GitHub Pages 배포 안내

수정 사항
1. 레벨 테스트 완료 버튼을 실제 폼 제출에 연결
2. 핸드 자동 전환용 타이머(handTransitionTimer) 선언

배포 방법
1. 이 ZIP의 index.html을 GitHub 저장소의 최상위 경로(root)에 업로드하세요.
2. 기존 index.html이 있으면 Replace/Commit changes로 교체하세요.
3. GitHub Settings > Pages에서 main 브랜치의 / (root)를 확인하세요.
4. 변경된 사이트를 새로고침해서 레벨 테스트 완료 -> 연습 테이블 전환을 확인하세요.

검증 범위
- Chromium headless 환경에서 HTML을 주입해 UI 동작을 테스트했습니다.
- 테스트 부분 제출 차단, 전체 제출, 6인 테이블 진입, 폴드, 핸드 자동 전환, 칩 유지 확인.
- 실제 GitHub Pages의 배포 상태나 휴대전화 실행은 이번 테스트에 포함되지 않았습니다.

주의: 이 프로젝트는 실물 화폐를 사용하지 않는 학습용 가상칩 시뮬레이터입니다.
